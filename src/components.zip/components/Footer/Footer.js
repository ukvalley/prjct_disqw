import React from 'react';
import PropTypes from 'prop-types';
import './Footer.css';

const Footer = () => (
  <div className="footer">
    <p>Sweekar Landmark</p>

  </div>
);

Footer.propTypes = {};

Footer.defaultProps = {};

export default Footer;
