import React from 'react';
import PropTypes from 'prop-types';
import './Home.css';

const Home = () => (
  <div className="Home">
    Home Component
  </div>
);

Home.propTypes = {};

Home.defaultProps = {};

export default Home;
