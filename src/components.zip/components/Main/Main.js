import React, { useState } from "react";
import PropTypes from 'prop-types';
import './Main.css';

import Navbar from '../Navbar/Navbar';
import Dashboard from '../Dashboard/Dashboard';
import Header from "../Header/Header";
import Footer from "../Footer/Footer";

import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from 'react-router-dom';

import Branch from "../Branch/Branch";
import Addbranch from "../Branch/addBranch";
import Viewbranch from "../Branch/viewBranch";
import Dailybalance from "../Branch/dailyBalance";

import JoinClient from "../Sale Property/JoinClient";
import ClientDetails from "../Sale Property/ClientDetails";
import SaleProperty from "../Sale Property/SaleProperty";
import ViewSaleProperty from "../Sale Property/ViewSaleProperty";
import UpdateSaleProperty from "../Sale Property/UpdateSaleProperty";
import ClientPayDetails from "../Sale Property/ClientPayDetails";
import PlotCancel from "../Sale Property/PlotCancel" ;
import CancelPlotList from "../Sale Property/CancelPlotList";
import DueInstallment from "../Sale Property/DueInstallment";

import DayCollection from "../Day Collection/DayCollection";

import AddExpenditure from "../Expenditure/AddExpenditure";
import ViewExpenditure from "../Expenditure/ViewExpenditure";
import AddOfficeExpenditure from "../Expenditure/AddOfficeExpenditure";
import ViewOfficeExpenditure from "../Expenditure/ViewOfficeExpenditure";

import AddReceivedHead from"../Received/AddReceivedHead"
import ViewReceivedHead from "../Received/ViewReceivedHead";
import AddOfficeExpenditureDetail from "../Received/AddOfficeExpenditureDetail";
import ViewReceived from"../Received/ViewReceived";

const Main = () => {

  const [menuCollapse, setMenuCollapse] = useState(false)

  //create a custom function that will change menucollapse state from false to true and true to false
  const menuIconClick = () => {
    //condition checking to change state from true to false and vice versa
    menuCollapse ? setMenuCollapse(false) : setMenuCollapse(true);
  };


  return (

    <div className="Main">
      

      <Header
        menuCollapse={menuCollapse}
        menuIconClick={menuIconClick}
      />

      <Navbar
        menuCollapse={menuCollapse}
        menuIconClick={menuIconClick}
      />
<Routes>
      <Route exact path='/' element={< Dashboard
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>
        <Route path='/dashboard' element={< Dashboard
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>

        <Route path='/addbranch' element={< Addbranch
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>
        <Route path='/Viewbranch' element={< Viewbranch
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>
        <Route path='/Dailybalance' element={< Dailybalance
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>

        <Route path='/JoinClient' element={< JoinClient
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>
         <Route path='/Clientdetails' element={< ClientDetails
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>
        <Route path='/SaleProperty' element={< SaleProperty
          menuCollapse={menuCollapse}
          menuIconClick={menuIconClick}
        />}></Route>
        <Route path='/ViewSaleProperty' element={<ViewSaleProperty
        menuCollapse={menuCollapse}
        menuIconClick={menuIconClick}
        />}></Route>
        <Route path='/UpdateSaleProperty' element={<UpdateSaleProperty
        menuCollapse={menuCollapse}
        menuIconClick={menuIconClick}
      />}></Route>
      <Route path='/ClientPayDetails' element={<ClientPayDetails
      menuCollapse={menuCollapse}
      menuIconClick={menuIconClick}
      />}></Route>
    <Route path='/PlotCancel' element={<PlotCancel
      menuCollapse={menuCollapse}
      menuIconClick={menuIconClick}
      />}></Route>      
      <Route path='/CancelPlotList' element={<CancelPlotList
      menuCollapse={menuCollapse}
      menuIconClick={menuIconClick}
      />}></Route>
      <Route path='/DueInstallment' element={<DueInstallment
      menuCollapse={menuCollapse}
      menuIconClick={menuIconClick}
      />}></Route>

    <Route path='/DayCollection' element={<DayCollection
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />}></Route>

    <Route path='/AddExpenditure' element={<AddExpenditure
       menuCollapse={menuCollapse}
       menuIconClick={menuIconClick}
    />}></Route>
    <Route path='/ViewExpenditure' element={<ViewExpenditure
       menuCollapse={menuCollapse}
       menuIconClick={menuIconClick}
    />}></Route>
    <Route path='/AddOfficeExpenditure'element={<AddOfficeExpenditure 
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />} ></Route>
    <Route path='/ViewOfficeExpenditure'element={<ViewOfficeExpenditure 
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />} ></Route>

    <Route path='/AddReceivedHead' element={<AddReceivedHead
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />}></Route>

    <Route path='/ViewReceivedHead' element={<ViewReceivedHead
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />}>     
    </Route>

    <Route path='/AddOfficeExpenditureDetail' element ={<AddOfficeExpenditureDetail
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />}></Route>


     <Route path='/ViewReceived' element ={<ViewReceived
    menuCollapse={menuCollapse}
    menuIconClick={menuIconClick}
    />}></Route>

</Routes >

      
    </div>
  )

};

Main.propTypes = {};

Main.defaultProps = {};

export default Main;
