import React from 'react';
import PropTypes from 'prop-types';
import './Components.css';

const Components = () => (
  <div className="Components">
    Components Component
  </div>
);

Components.propTypes = {};

Components.defaultProps = {};

export default Components;
